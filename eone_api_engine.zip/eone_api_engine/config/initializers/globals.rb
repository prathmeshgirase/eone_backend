STUDENT = 'Student'.freeze
ADMIN = 'Admin'.freeze
TEACHER = 'Teacher'.freeze
COMPANY = 'Comapany'.freeze
