## Eone API Engine – Backend API

### Architecture
- **Centralized (monolithic) API** built with **Rails 7.1 (API-only)** and **Ruby 3.1.2**.
- Single service, single codebase, single runtime. No microservices or multi-service orchestration.

### Tech stack
- **Framework**: Rails 7.1 (API-only)
- **Language**: Ruby 3.1.2
- **DB**: PostgreSQL
- **Web server**: Puma
- **Auth**: JWT (custom helper), bcrypt (passwords)
- **Serialization**: Blueprinter
- **Uploads**: Active Storage (local in development)
- **CORS**: rack-cors

### Project structure (key paths)
- `app/controllers/api/v1/`: REST API controllers
  - `auth_controller.rb`: Login and JWT issuance
  - `users_controller.rb`: Register, list/show, approvals, dashboard counts
  - `roles_controller.rb`: List non-admin roles
  - `classrooms_controller.rb`: List/create classrooms
  - `subjects_controller.rb`: Create subjects, list by teacher
  - `assignments_controller.rb`: Create and list assignments; submissions listing
  - `assignment_submissions_controller.rb`: Create/update assignment submissions
  - `notifications_controller.rb`: Fetch notifications for a user
- `app/models/`: ActiveRecord models (e.g., `user.rb`, `classroom.rb`, `subject.rb`, `assignment.rb`, `assignment_submission.rb`, `notification.rb`, `role.rb`)
- `app/serializers/`: Blueprinter serializers for clean JSON output
- `app/channels/`, `app/jobs/`, `app/mailers/`: Action Cable, background jobs, email
- `lib/json_web_token.rb`: JWT encode/decode helper
- `config/routes.rb`: All API routes (versioned under `/api/v1`)
- `config/application.rb`: Rails config; app runs in API-only mode
- `config/environments/*`: Env-specific configuration
- `config/initializers/*`: CORS, globals, etc. Notable: `globals.rb` defines role names
- `config/database.yml`: PostgreSQL settings (dev/test)
- `config/puma.rb`: Puma server config
- `db/migrate/`: Database migrations
- `db/schema.rb`: Current schema
- `db/seeds.rb`: Seed data (currently empty)
- `Gemfile`: Dependencies (rails, pg, puma, jwt, blueprinter, bcrypt, rack-cors, etc.)
- `Dockerfile`: Container build for the API
- `bin/*`: Rails executables (`rails`, `rake`, `setup`, `docker-entrypoint`)
- Runtime dirs: `log/`, `tmp/`, `storage/`, `public/`

### Setup
#### Prerequisites
- Ruby 3.1.2 and Bundler
- PostgreSQL server
- Node/Yarn are not required (API-only)

#### Database configuration
Default dev/test settings live in `config/database.yml`:

```yml
default: &default
  adapter: postgresql
  encoding: unicode
  pool: 25
  username: postgres
  password: psql24

development:
  <<: *default
  database: eone_dev

test:
  <<: *default
  database: eone_test
```

Update `username`/`password` as needed for your local PostgreSQL, or export `PG*` env vars. Create the `eone_dev` database or let Rails create it.

#### Install and run (local)
```bash
cd eone_api_engine
bundle install
bin/rails db:setup   # creates, migrates, seeds (seeds is currently empty)
bin/rails server -p 3000
```

The API will be available at `http://localhost:3000`.

#### Secrets
- JWT uses `Rails.application.secrets.secret_key_base`.
- In development, Rails generates this automatically.
- In production, set `RAILS_MASTER_KEY` (to read `config/credentials.yml.enc`) or provide `SECRET_KEY_BASE`.

### Running with Docker
```bash
cd eone_api_engine
docker build -t eone_api .
docker run --rm -p 3000:3000 \
  -e RAILS_ENV=production \
  -e DATABASE_URL="postgres://USER:PASS@HOST:5432/DBNAME" \
  -e SECRET_KEY_BASE="<your-secret>" \
  eone_api
```

Notes:
- Ensure the Postgres DB is reachable from the container and already migrated.
- You can run `bin/rails db:migrate` inside the container or migrate externally.

### Authentication model
- `POST /api/v1/login` returns a JWT embedded in the response under `user.token`.
- A reusable `Authenticate` concern exists that can enforce `Authorization: Bearer <token>`, but it is not currently included in controllers. To protect endpoints, include it where needed:

```ruby
# app/controllers/application_controller.rb
class ApplicationController < ActionController::API
end

# To enforce auth on all controllers, change to:
# class ApplicationController < ActionController::API
#   include Authenticate
# end
```

### API usage with Postman
Base URL: `http://localhost:3000`

Default headers:
- `Content-Type: application/json`

If you enable JWT protection (optional):
- `Authorization: Bearer <token>`

#### Roles
- GET `/api/v1/roles`
  - Returns non-admin roles: `[{ id, name }, ...]`

#### Registration and login
- POST `/api/v1/register`
  - Body:
    ```json
    {
      "user": {
        "email": "student1@example.com",
        "name": "Student One",
        "password": "secret123",
        "password_confirmation": "secret123",
        "mobile_number": "9999999999",
        "date_of_birth": "2000-01-01",
        "role_id": 2,
        "classroom_id": 1
      }
    }
    ```
  - Response: confirmation message and user record (status pending).

- PATCH `/api/v1/users/:id/approve`
  - Approves a user; no body required.

- POST `/api/v1/login`
  - Body:
    ```json
    { "email": "student1@example.com", "password": "secret123" }
    ```
  - Response: `{ user: { ..., token: "<jwt>" } }`

#### Users
- GET `/api/v1/users`
- GET `/api/v1/users/:id`
- GET `/api/v1/users/admin_dashboard_count`
- GET `/api/v1/users/:id/teacher_dashboard_count`
- GET `/api/v1/pending_approvals?type=Teacher|Student&teacher_id=<optional>`
- GET `/api/v1/approved_users?type=Teacher|Student`

#### Classrooms
- GET `/api/v1/classrooms`
- POST `/api/v1/classrooms`
  - Body:
    ```json
    { "classroom": { "name": "CS-A", "batch": "2025", "year": 3 } }
    ```

#### Subjects
- POST `/api/v1/subjects`
  - Body:
    ```json
    {
      "subject": {
        "name": "Math",
        "start_time": "09:00",
        "end_time": "10:00",
        "teacher_id": 5,
        "classroom_id": 1,
        "days_list": ["Mon", "Wed"]
      }
    }
    ```
- GET `/api/v1/users/:id/subjects` (id = teacher user id)

#### Assignments
- POST `/api/v1/assignments`
  - JSON body (no file):
    ```json
    {
      "assignment": {
        "title": "HW1",
        "description": "Solve problems 1-5",
        "due_date": "2025-08-31",
        "subject_id": 3,
        "teacher_id": 5
      }
    }
    ```
  - Multipart (file upload): use keys `assignment[title]`, `assignment[file]`, etc.

- GET `/api/v1/assignments?teacher_id=5`
- GET `/api/v1/assignments?student_id=10`
- GET `/api/v1/assignments/:id/submissions`

#### Assignment submissions
- POST `/api/v1/assignment_submissions` (multipart/form-data)
  - Keys:
    - `assignment_submission[assignment_id]`
    - `assignment_submission[user_id]`
    - `assignment_submission[file]` (file)

- PATCH `/api/v1/assignment_submissions/:id`
  - Body:
    ```json
    { "marks": 90, "grade": "A" }
    ```

#### Notifications
- GET `/api/v1/users/:id/notifications?limit=10`

### Data and roles
- Role constants live in `config/initializers/globals.rb`:
  - `ADMIN = 'Admin'`, `TEACHER = 'Teacher'`, `STUDENT = 'Student'`, `COMPANY = 'Comapany'` (note the spelling)
- Ensure your `roles` table contains these names so `role_id` references are valid.
- `db/seeds.rb` is empty; you can seed via Rails console, e.g.:

```ruby
Role.find_or_create_by!(name: 'Admin')
Role.find_or_create_by!(name: 'Teacher')
Role.find_or_create_by!(name: 'Student')
Role.find_or_create_by!(name: 'Comapany') # matches constant

classroom = Classroom.find_or_create_by!(name: 'CS-A', batch: '2025', year: 3)
```

### File uploads (Active Storage)
- Development uses local disk per `config/storage.yml`.
- For Postman uploads, use `multipart/form-data` with nested keys like `assignment[file]` or `assignment_submission[file]`.

## Backend flow

### User lifecycle (registration → approval → login)
- Register: `POST /api/v1/register` creates a user with `status = pending`.
- Approve/Reject: Admin updates status via `PATCH /api/v1/users/:id/approve` or `PATCH /api/v1/users/:id/reject`.
  - Triggers mailers: `UserMailer.approval_email` or `UserMailer.rejection_email`.
- Login: `POST /api/v1/login`
  - Only approved users can log in.
  - Returns `{ user: { ..., token: <jwt> } }` generated by `JsonWebToken.encode`.
- Authorization (optional): To enforce JWT on endpoints, include `Authenticate` in controllers (not enabled by default).

### Teacher workflow
- Create classroom: `POST /api/v1/classrooms` (admin/authorized user creates classes).
- Create subjects: `POST /api/v1/subjects` with `teacher_id` and `classroom_id`.
- Create assignments: `POST /api/v1/assignments` (optionally with file via multipart).
  - On create, a `Notification` is stored for that assignment.
  - Teachers can list their assignments: `GET /api/v1/assignments?teacher_id=<teacher_user_id>`.
- View student submissions to an assignment: `GET /api/v1/assignments/:id/submissions`.
- Grade a submission: `PATCH /api/v1/assignment_submissions/:id` with `{ marks, grade }`.
- Check notifications: `GET /api/v1/users/:id/notifications?limit=N` (returns messages relevant to the teacher's assignments).

### Student workflow
- Register → Approval → Login (same as above).
- See assignments for their classroom: `GET /api/v1/assignments?student_id=<student_user_id>`.
- Submit assignment: `POST /api/v1/assignment_submissions` (multipart with `assignment_submission[file]`).
- Check notifications: `GET /api/v1/users/:id/notifications?limit=N` (assignment announcements for the student's classroom).

### Notifications flow
- Assignment creation (`POST /api/v1/assignments`): creates a `Notification` associated to the assignment. Students see these via `/users/:id/notifications` as classroom-wide announcements.
- Assignment submission (`POST /api/v1/assignment_submissions`): creates a `Notification` tied to the assignment and submitting user. Teachers see these via `/users/:id/notifications` as submission alerts.
- Retrieval logic: `Api::V1::NotificationsController#index` resolves the current user's role and returns messages accordingly, always shaped as `{ message, created_at }`.

### Dashboard metrics
- Admin: `GET /api/v1/users/admin_dashboard_count`
  - `pending_approvals_count`: number of pending users for roles `Teacher` and `Comapany`.
  - `classroom_count`: total classrooms.
- Teacher: `GET /api/v1/users/:id/teacher_dashboard_count`
  - `subject_count`: number of subjects taught by the teacher.
  - `student_count`: students in the teacher's classroom.
  - `assignment_count`: assignments created by the teacher.
  - `pending_approval_count`: pending students in the teacher's classroom.

### Request lifecycle (internals)
- HTTP request → `config/routes.rb` → `Api::V1::*Controller` action → ActiveRecord models (`app/models`) → JSON rendering via Blueprinter (`app/serializers`) → HTTP JSON response.
- JWT handling via `lib/json_web_token.rb`. Add `Authenticate` concern to controllers to enforce `Authorization: Bearer <jwt>` headers.

### Troubleshooting
- DB connection errors: verify `config/database.yml` credentials and that PostgreSQL is running.
- JWT decode errors: ensure `SECRET_KEY_BASE`/`RAILS_MASTER_KEY` are set appropriately across environments.
- 401 Unauthorized (if you enable auth): include `Authorization: Bearer <token>` header from login response.

### License
Internal/Project-specific. Add a license here if needed.

<<<<<<< HEAD
# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
=======
# eone_backend
>>>>>>> a52cb5cb372f36c208a9ab0c1c9a759f54624118
