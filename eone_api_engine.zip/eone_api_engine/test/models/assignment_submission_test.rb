require "test_helper"

class AssignmentSubmissionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
